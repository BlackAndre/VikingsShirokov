it's a java app called Viking Wars.

You should launch the application through the launch of "StartOfWar"
You need to enter the number of map, then the number of Vikings.
After the 10000 days or if Vikings cannot go anywhere of there aren`t alive vikings the app will stop and print the current map.
